package com.comparison.compareDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompareDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompareDbApplication.class, args);
	}

}
