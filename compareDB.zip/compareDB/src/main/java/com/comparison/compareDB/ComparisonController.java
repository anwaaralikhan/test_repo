package com.comparison.compareDB;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.bind.annotation.*;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
@RestController
@CrossOrigin
public class ComparisonController {
    @Autowired
    private ComparisonService cServices;


    @GetMapping("api/comparison/table")
    public List data(@RequestParam(value = "tbl") String tblname) {
    return  cServices.getAllTblData(tblname);
    }

    @GetMapping("api/comparison/query")
    public List dataByQuery(@RequestParam(value = "query") String query) {
        return  cServices.getDataByQuery(query);
    }
    @GetMapping("api/comparison/tables")
    public  List getTables( ){
        return  cServices.getTablesOfDB();
    }

}
