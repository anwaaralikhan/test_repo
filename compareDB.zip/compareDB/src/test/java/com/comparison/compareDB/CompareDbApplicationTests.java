package com.comparison.compareDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompareDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
