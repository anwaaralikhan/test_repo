package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.bind.annotation.*;
import  com.example.demo.CompareServices;

import java.util.List;
@RestController
@CrossOrigin
public class CompareController {
    @Autowired
    private CompareServices  cServices;

    @Autowired
    private CompareServices2  cServices2;

    @PostMapping("api/comparison/table")
    public List data(@RequestBody TableRequest tblReq) {

        if(tblReq.getDb().equals("db1"))
        {

            return  cServices.getAllTblData(tblReq.getTbl());
        }
        else{

            return  cServices2.getAllTblData(tblReq.getTbl());
        }
    }

    @PostMapping("api/comparison/query")
    public List dataByQuery(@RequestBody QueryRequest qryReq) {
        System.out.println(qryReq.getQuery());
        if(qryReq.getDb().equals("db1"))
        return  cServices.getDataByQuery(qryReq.getQuery());
        else
            return  cServices2.getDataByQuery(qryReq.getQuery());
    }
    @GetMapping("api/comparison/tables")
    public  List getTables( ){
        return  cServices.getTablesOfDB();
    }

}
