package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import javax.sql.DataSource;

@Service
public class CompareServices2 {

    @Autowired @Qualifier("jdbc2")
    private JdbcTemplate  jdbcTemplate;;

    public List getAllTblData(String tbl){
        return (List) jdbcTemplate.queryForList("select * from "+tbl);
    }
    public  List getDataByQuery(String q){
        return (List) jdbcTemplate.queryForList(q);
    }

    public  List getTablesOfDB() {
        return  jdbcTemplate.queryForList("show tables");
    }


}
