package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.*;

@Configuration
public class DataSourceConfig {

    @Bean (name = "mysqlDataSource") @Primary
    public DataSource mysqlDataSource() {
        final DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setUrl("jdbc:mysql://localhost:3306/testcomparison");
        dataSource.setUsername("root");
        dataSource.setPassword("");
        return dataSource;
    }

    @Bean (name ="jdbc1") @Primary
    public JdbcTemplate DataSource1JDBC() {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(mysqlDataSource());
        return jdbcTemplate;
    }
}
