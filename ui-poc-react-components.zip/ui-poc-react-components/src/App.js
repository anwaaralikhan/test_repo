import "./App.css";
import Comparison from "./Components/Comparison";

function App() {
  return <Comparison />;
}

export default App;
