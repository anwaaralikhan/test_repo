import React, { useEffect, useState } from "react";

import Papa from "papaparse";
import {
  AppBar,
  Box,
  Button,
  Grid,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Toolbar,
  Typography,
} from "@mui/material";
import { FileUpload, Menu } from "@mui/icons-material";
import { green, grey, red } from "@mui/material/colors";
import { GridSheet } from "./GridSheet";

const allowedExtensions = ["csv"];
export default function Comparison() {
  const [dataL, setDataL] = useState([]);
  const [errorL, setErrorL] = useState([]);
  const [errorR, setErrorR] = useState([]);
  const [dataR, setDataR] = useState([]);
  const [columns, setColumns] = useState([]);
  const handleFileChange = (e) => {
    if (e.target.files.length) {
      const inputFile = e.target.files[0];
      const name = e.target.name;
      const fileExtension = inputFile?.type.split("/")[1];
      if (!allowedExtensions.includes(fileExtension)) {
        return;
      }
      const reader = new FileReader();
      reader.onload = async ({ target }) => {
        const csv = Papa.parse(target.result, { header: true });
        const parsedData = csv?.data;
        const columns = Object.keys(parsedData[0]);
        let cols = [];
        for (let i = 0; i < columns.length; i++) {
          cols.push(columns[i]);
        }
        setColumns(cols);
        if (name === "left") setDataL(parsedData);
        else if (name === "right") setDataR(parsedData);
      };
      reader.readAsText(inputFile);
    }
  };
  const diffData = (dataL, dataR, type) => {
    let errors = [];
    dataL.forEach((rowL, indexL) => {
      dataR.forEach((rowR, indexR) => {
        if (indexL === indexR) {
          for (let keyL in rowL) {
            let rowIndex = 0;
            for (let keyR in rowR) {
              if (keyL === keyR) {
                if (rowL[keyL] !== rowR[keyR]) {
                  if (rowR[keyR] === "") {
                    errors.push({
                      index: indexR,
                      key: rowIndex,
                      type: "blank",
                    });
                  } else {
                    errors.push({
                      index: indexR,
                      key: keyR,
                      type: type,
                    });
                  }
                }
              }
              rowIndex++;
            }
          }
        }
      });
    });
    return errors;
  };
  useEffect(() => {
    if (dataL.length > 0 && dataR.length > 0) {
      let errR = diffData(dataL, dataR, "modified");
      setErrorR(errR);
      let errL = diffData(dataR, dataL, "deleted");
      setErrorL(errL);
    }
  }, [dataL, dataR]);

  const CheckRowForError = (index, key, error) => {
    let result = null;
    error.forEach((err) => {
      if (err.index === index && err.key === key) {
        result = err.type;
      }
    });
    return result;
  };
  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2 }}
          >
            <Menu />
          </IconButton>
          <Typography
            fontWeight={"bold"}
            variant="h6"
            component="div"
            sx={{ flexGrow: 1 }}
          >
            Components
          </Typography>
          <Button color="inherit">Login</Button>
        </Toolbar>
      </AppBar>
      <Box>
        <Box display={"flex"} flexWrap="wrap">
          <Box display={"flex"} justifyContent={"center"}>
            <Box padding={"10px"}>
              <label htmlFor="upload-file1">
                <input
                  style={{ display: "none" }}
                  name="left"
                  id="upload-file1"
                  type="file"
                  onChange={handleFileChange}
                  disabled={dataL.length > 0}
                />

                <Button
                  color="primary"
                  variant="contained"
                  component="span"
                  disabled={dataL.length > 0}
                >
                  <FileUpload /> Upload First .CSV File
                </Button>
              </label>
            </Box>
          </Box>
          <Box display={"flex"} justifyContent={"center"} flex={1}>
            <Box padding={"10px"}>
              {" "}
              <label htmlFor="upload-file2">
                <input
                  style={{ display: "none" }}
                  id="upload-file2"
                  name="right"
                  type="file"
                  onChange={handleFileChange}
                  width="50vw"
                  accept="csv"
                  disabled={dataR.length > 0}
                />

                <Button
                  color="primary"
                  variant="contained"
                  component="span"
                  disabled={dataR.length > 0}
                >
                  <FileUpload /> Upload Second .CSV File
                </Button>
              </label>
            </Box>
          </Box>
        </Box>
      </Box>
      {dataL.length > 0 && dataR.length > 0 && (
        <>
          <Grid container spacing={1} padding="10px">
            <Grid item xs={12} display="flex">
              <Box display={"flex"} mx="5px">
                <Box
                  sx={{ width: "20px", height: "20px", background: green[200] }}
                ></Box>{" "}
                <Box>
                  <Typography>Modified</Typography>
                </Box>
              </Box>
              <Box display={"flex"} mx="5px">
                <Box
                  sx={{ width: "20px", height: "20px", background: red[200] }}
                ></Box>{" "}
                <Box>
                  <Typography>Deleted</Typography>
                </Box>
              </Box>
              <Box display={"flex"} mx="5px">
                <Box
                  sx={{ width: "20px", height: "20px", background: grey[200] }}
                ></Box>{" "}
                <Box>
                  <Typography>Blank</Typography>
                </Box>
              </Box>
            </Grid>
            <Grid lg={6} xs={12} item>
              <Typography variant="h6" fontWeight={"bold"}>
                Original File
              </Typography>
              <GridSheet
                data={dataL}
                columns={columns}
                changes={errorR}
                type="left"
              />
            </Grid>
            <Grid lg={6} xs={12} item>
              <Typography variant="h6" fontWeight={"bold"}>
                Modified File
              </Typography>

              <GridSheet
                data={dataR}
                columns={columns}
                changes={errorL}
                type="right"
              />
            </Grid>
          </Grid>
        </>
      )}
    </>
  );
}
