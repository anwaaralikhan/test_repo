import { HotColumn, HotTable } from "@handsontable/react";
import { registerAllModules } from "handsontable/registry";
import { registerRenderer, textRenderer } from "handsontable/renderers";
import "handsontable/dist/handsontable.full.min.css";
import { green, red } from "@mui/material/colors";

// register Handsontable's modules
registerAllModules();

export const GridSheet = ({ data, columns, changes, type }) => {
  function RowRenderer(instance, td, row, col, prop, value, cellProperties) {
    textRenderer.apply(this, arguments);
    if (CheckRowForError(row, col)) {
      td.style.fontWeight = "bold";
      td.style.color = "white";
      td.style.background = type === "left" ? red[200] : green[200];
    }
  }
  const CheckRowForError = (index, key, error) => {
    let result = null;
    changes?.forEach((err) => {
      if (err.index === index && err.key === key) {
        result = err.type;
      }
    });
    return result;
  };
  function negativeValueRenderer(
    instance,
    td,
    row,
    col,
    prop,
    value,
    cellProperties
  ) {
    textRenderer.apply(this, arguments);

    // if row contains negative number
    if (parseInt(value, 10) < 0) {
      // add class "negative"
      td.className = "make-me-red";
    }

    if (!value || value === "") {
      td.style.background = "#EEE";
    } else {
      if (value === "Nissan") {
        td.style.fontStyle = "italic";
      }

      td.style.background = "";
    }
  }
  //  maps function to a lookup string
  registerRenderer("negativeValueRenderer", negativeValueRenderer);

  return (
    <HotTable
      data={data}
      licenseKey="non-commercial-and-evaluation"
      height="auto"
      afterSelection={function (row, col, row2, col2) {
        const meta = this.getCellMeta(row2, col2);

        if (meta.readOnly) {
          this.updateSettings({ fillHandle: false });
        } else {
          this.updateSettings({ fillHandle: true });
        }
      }}
      cells={function (row, col) {
        const cellProperties = {};
        const data = this.instance.getData();
        cellProperties.renderer = RowRenderer;
        // if (row === 0 || (data[row] && data[row][col] === "readOnly")) {
        //   cellProperties.readOnly = true; // make cell read-only if it is first row or the text reads 'readOnly'
        // }

        // if (row === 0) {
        //   cellProperties.renderer = RowRenderer; // uses function directly
        // } else {
        //   cellProperties.renderer = "negativeValueRenderer"; // uses lookup map
        // }
        cellProperties.readOnly = true;
        return cellProperties;
      }}
    />
  );
};
