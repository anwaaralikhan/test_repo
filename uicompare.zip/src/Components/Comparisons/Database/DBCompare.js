import { PlayArrow } from "@mui/icons-material";
import { Box, Grid, IconButton, Typography } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import CompareDataGrid2 from "../../Common/DataGrid/CompareDataGrid2";
import RecentQueryDialog from "./Dialogs/RecentQueryDialog";
import QueryEditor from "./QueryEditor";

export default function DBCompare({tabID}) {
  const [queries, setQueries] = useState({
    db1SqlQuery: "",
    db2SqlQuery: "",
    db1Source: "DB1",
    db2Source: "DB1",
  });
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [filter, setFilter] = useState("");
  const [dbs, setDBs] = useState([]);
  const [recentQueries, setRecentQueries] = useState({
    tbl1: [],
    tbl2: [],
  });
  const [openQueriesDialog, setOpenQueriesDialog] = useState({
    tbl1QueryDialog: false,
    tbl2QueryDialog: false,
  });
  let dataTypes = { DATE: "date", VARCHAR: "text", INT: "numeric" };
  useEffect(() => {
    let databases = sessionStorage.getItem("dbs_" +tabID);
    let recentQueries = sessionStorage.getItem("recentQueries_" +tabID);
       let gridData = sessionStorage.getItem("data_"+tabID) || [];
       let gridColumns = sessionStorage.getItem("columns_"+tabID) || [];

    if (recentQueries && recentQueries?.length > 0)
      setRecentQueries(JSON.parse(recentQueries));
      else setRecentQueries({
    tbl1: [],
    tbl2: [],
  })
  if(gridData && gridData?.length > 0)setData(JSON.parse(gridData) )
  else setData([])
  if (gridColumns && gridColumns?.length > 0)setColumns(JSON.parse(gridColumns) )
  else setColumns([])
    if (databases && databases?.length > 0) setDBs(JSON.parse(databases));
    else
      setDBs([
        { label: "Database 1", value: "DB1" },
        { label: "Database 2", value: "DB2" },
      ]);

      setQueries({
    db1SqlQuery: "",
    db2SqlQuery: "",
    db1Source: "DB1",
    db2Source: "DB1",
  })
  }, [tabID]);
  let handleQueryExecution = () => {
    if (queries.db1SqlQuery === "" || queries.db2SqlQuery === "") {
      alert("Please Enter 2 Queries to execute");
      return;
    } else if (queries.db1Source === "" || queries.db2Source === "") {
      alert("Please Select Data Sources ");
      return;
    }
    let tbl1RecentQueries = recentQueries.tbl1;
    if (!tbl1RecentQueries.some((qry) => qry?.qry === queries.db1SqlQuery))
      tbl1RecentQueries.push({
        qry: queries.db1SqlQuery,
        source: queries.db1Source,
      });

    let tbl2RecentQueries = recentQueries.tbl2;
    if (!tbl2RecentQueries.some((qry) => qry?.qry === queries.db2SqlQuery))
      tbl2RecentQueries.push({
        qry: queries.db2SqlQuery,
        source: queries.db2Source,
      });
    setRecentQueries({
      ...recentQueries,
      tbl1: tbl1RecentQueries,
      tbl2: tbl2RecentQueries,
    });
    axios
      .post("http://localhost:8080/compare/datagrid/row", queries)
      .then((response) => {
        if (response.data.rows.length > 0) {
          let data = response.data.rows;
          if (data[0]?.rows?.length > 0) {
            let cols = data[0].rows?.map((col) => {
              return [
                {
                  title: col?.columnName,
                  type: dataTypes[col?.dataType] || "text",
                },
              ];
            });
            let allCols = [
              {
                title: "rowNo",
                type: "numeric",
              },
            ];
            for (const col of cols) {
              allCols.push(col[0]);
            }
            sessionStorage.setItem("data_"+tabID,JSON.stringify(data))
            sessionStorage.setItem("columns_"+tabID,JSON.stringify(allCols))
            setData(data);
            setColumns(allCols);
          } else alert("No Columns Found");
        } else alert("No Data Found");
      })
      .catch((err) => Swal.fire("Error!", err.message, "error"));
  };
  let allRows = [];

  for (const row of data) {
    let singleRow = {};
    for (const col of row?.rows) {
      let col1 = col?.columnName;
      let col2 = col?.columnName;
      singleRow["rowNo"] = col?.rowNo;
      singleRow[col1] = col?.columnValue;
      singleRow[col2] = col?.columnValue;
      singleRow[col1 + "_different"] = col?.different;
      singleRow[col1 + "_onlyInDb2"] = col?.onlyInDb2;
      singleRow[col1 + "_nullInBoth"] = col?.nullInBoth;
      singleRow[col1 + "_onlyInDb1"] = col?.onlyInDb1;
      singleRow[col2 + "_different"] = col?.different;
      singleRow[col2 + "_onlyInDb2"] = col?.onlyInDb2;
      singleRow[col2 + "_nullInBoth"] = col?.nullInBoth;
      singleRow[col2 + "_onlyInDb1"] = col?.onlyInDb1;
      singleRow[col1 + "_comments"] = col?.comments;
      singleRow[col2 + "_error"] = col?.error;
    }
    allRows.push(singleRow);
  }

  if (filter !== "")
    allRows = allRows.filter((row) => {
      let arrOfCols = Object.keys(row);
      let filterCols = arrOfCols.filter((col) => col.includes(filter));
      return filterCols.some((col) => row[col]);
    });

  useEffect(() => {
    if (dbs.length > 0)
      sessionStorage.setItem("dbs_" +tabID, JSON.stringify(dbs));
  }, [dbs]);
  useEffect(() => {
    if (recentQueries.tbl1.length > 0 || recentQueries.tbl2.length > 0)
      sessionStorage.setItem(
        "recentQueries_" +tabID,
        JSON.stringify(recentQueries)
      );
  }, [recentQueries]);
  return (
    <Box padding={"10px"}>
      <Box my={"10px"}>
      <Typography textAlign={'center'} variant="h6">{"Tab No. " + tabID}</Typography>
      </Box>
      <Grid container spacing={2}>
        <Grid item md={6} xs={12}>
          <QueryEditor
            title={"Table 1 Query"}
            query={queries.db1SqlQuery}
            db={queries.db1Source}
            setDB={(db) => setQueries({ ...queries, db1Source: db })}
            setQuery={(qry) => setQueries({ ...queries, db1SqlQuery: qry })}
            dbs={dbs}
            setDBs={setDBs}
            onRecentQueriesOpen={() =>
              setOpenQueriesDialog({
                ...openQueriesDialog,
                tbl1QueryDialog: true,
              })
            }
          />{" "}
        </Grid>
        <Grid item md={6} xs={12}>
          <QueryEditor
            title={"Table 2 Query"}
            query={queries.db2SqlQuery}
            setQuery={(qry) => setQueries({ ...queries, db2SqlQuery: qry })}
            db={queries.db2Source}
            setDB={(db) => setQueries({ ...queries, db2Source: db })}
            dbs={dbs}
            setDBs={setDBs}
            onRecentQueriesOpen={() =>
              setOpenQueriesDialog({
                ...openQueriesDialog,
                tbl2QueryDialog: true,
              })
            }
          />
        </Grid>
        <Grid item xs={12} position="relative">
          <Box display={"flex"} justifyContent="center">
            <Box
              sx={{
                position: { md: "absolute" },
                top: {
                  md: "-35px",
                },
              }}
            >
              <IconButton
                size="large"
                sx={{
                  background: "#198754",
                  color: "white",
                  "&:hover": {
                    md: {
                      backgroundColor: "#f7f3f3",
                      color: "#198754",
                    },
                    xs: {
                      backgroundColor: "#198754",
                      color: "#f7f3f3",
                    },
                  },
                }}
                onClick={handleQueryExecution}
              >
                <PlayArrow
                  sx={{
                    "&:hover": {
                      md: {
                        color: "#198754",
                      },
                      xs: {
                        color: "#f7f3f3",
                      },
                    },
                  }}
                />
              </IconButton>
            </Box>
          </Box>
        </Grid>
      </Grid>
     <Box sx={{height:"50vh"}}>
       {data.length > 0 && (
        <>
          {/* <CompareDataGrid
            columns={columns}
            data={allRows}
            setFilter={setFilter}
            filter={filter}
          /> */}
          <CompareDataGrid2
            columns={columns}
            data={allRows}
            setFilter={setFilter}
            filter={filter}
          />
        </>
      )}
     </Box>
      <RecentQueryDialog
        open={openQueriesDialog.tbl1QueryDialog}
        type="tbl1"
        recentQueries={recentQueries}
        queries={recentQueries.tbl1}
        setRecentQueries={setRecentQueries}
        setOpen={(val) =>
          setOpenQueriesDialog({ ...openQueriesDialog, tbl1QueryDialog: false })
        }
        setQuery={(qry) =>
          setQueries({
            ...queries,
            db1SqlQuery: qry?.qry,
            db1Source: qry?.source,
          })
        }
      />
      <RecentQueryDialog
        recentQueries={recentQueries}
        type="tbl2"
        open={openQueriesDialog.tbl2QueryDialog}
        setRecentQueries={setRecentQueries}
        queries={recentQueries.tbl2}
        setOpen={(val) =>
          setOpenQueriesDialog({ ...openQueriesDialog, tbl2QueryDialog: false })
        }
        setQuery={(qry) =>
          setQueries({
            ...queries,
            db2SqlQuery: qry?.qry,
            db2Source: qry?.source,
          })
        }
      />
    </Box>
  );
}
