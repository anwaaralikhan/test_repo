import { FileUpload } from "@mui/icons-material";
import { Grid, Box, Button } from "@mui/material";
import React from "react";

export default function FileCompare() {
  return (
    <div>
      {" "}
      <Grid container display={"flex"} flexWrap="wrap">
        <Grid md={6} xs={12} item>
          <Box padding={"10px"} display="flex" alignItems={"center"}>
            <Box>
              <label htmlFor="upload-file1">
                <input
                  style={{ display: "none" }}
                  name="left"
                  id="upload-file1"
                  type="file"
                  // onChange={handleFileChange}
                />

                <Button
                  className="bg-dark"
                  variant="contained"
                  component="span"
                >
                  <FileUpload /> Upload First .CSV File
                </Button>
              </label>
            </Box>
          </Box>
        </Grid>{" "}
        <Grid md={6} xs={12} item>
          <Box padding={"10px"} display="flex" alignItems={"center"}>
            <Box>
              <label htmlFor="upload-file1">
                <input
                  style={{ display: "none" }}
                  name="left"
                  id="upload-file1"
                  type="file"
                  // onChange={handleFileChange}
                />

                <Button
                  className="bg-dark"
                  variant="contained"
                  component="span"
                >
                  <FileUpload /> Upload Second .CSV File
                </Button>
              </label>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </div>
  );
}
